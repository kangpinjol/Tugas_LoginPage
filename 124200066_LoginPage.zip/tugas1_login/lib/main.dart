import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({Key? key}) :super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Login Screen - 124200066'),
          backgroundColor: Colors.black,
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 50) ,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                  'assets/aa.png',
                  width: 500,
                  height: 300,
                ),
                SizedBox(height: 30,),
              TextFormField(
                decoration: const InputDecoration(
                icon: Icon(Icons.person),
                hintText: 'Example : flutter@gmail.com',
                labelText: 'Username',
                border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: const InputDecoration(
                icon: Icon(Icons.password),
                hintText: '',
                labelText: 'Password',
                border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              TextButton(
                onPressed: () {}, 
                child: Text('Forgot Passwrod?')//hyper link
                ),
                SizedBox(height: 5),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 70),
                child: SizedBox(
                  width: 500,
                  height: 30,
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text('Login'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blue,
                      textStyle: TextStyle(
                        fontSize: 15,
                    )
                  ),
                ),
                  ),
                ),
                
            ],
          ),
        ),
      ),

    );
  }
}