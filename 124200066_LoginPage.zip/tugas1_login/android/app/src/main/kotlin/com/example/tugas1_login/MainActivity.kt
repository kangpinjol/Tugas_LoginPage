package com.example.tugas1_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
